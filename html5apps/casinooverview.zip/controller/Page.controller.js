sap.ui.define(['sap/m/MessageToast', 'sap/ui/core/mvc/Controller'],
	function (MessageToast, Controller){
	"use strict";

	var PageController = Controller.extend("sap.stickiness.casino.controller.Page", {

		press: function (oEvent) {
			MessageToast.show("Here we need to implement a jump into the stickiness app for one single casino.");
		},
		onInit: function(){
			var oModel = this.getOwnerComponent().getModel();
			
			setInterval(function() { 
				var url = "/sentimentservice";
            	oModel.loadData(url, null, false);
            	oModel.refresh();
			}, 4000);
		}

	});

	return PageController;

});