sap.ui.define(['sap/m/MessageToast', 'sap/ui/core/mvc/Controller'],
	function (MessageToast, Controller){
	"use strict";

	var PageController = Controller.extend("sap.stickiness.slotmachine.controller.Page", {

	onInit: function(){
		var oModel = this.getOwnerComponent().getModel();
		var modeli18n = this.getOwnerComponent().getModel("i18n");
		 var oBundle = modeli18n.getResourceBundle();
         var casinoid= oBundle.getText("casinoid");
         
         var url = "/sentimentservice/" + casinoid + "/slotMachines";
         oModel.loadData(url, null, false);
         oModel.refresh();
            	
		setInterval(function() { 
            	oModel.loadData(url, null, false);
            	oModel.refresh();
			}, 4000);
		}

	});

	return PageController;

});